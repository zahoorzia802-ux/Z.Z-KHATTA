@rem Gradle wrapper
@gradle %*
